import 'package:chat/root/app_root.dart';
import 'package:flutter/material.dart';

void main() {
  runApp(const AppRoot());
}

