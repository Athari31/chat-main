class Person{

String? name;
String? image;
String? message;



Person({this.name,this.image,this.message});

}